export class Customer {
    public cid : number;
    public cname : string;
    public cphno: string;
    public cusername : string;
    public cpassword : string;
    public cemail : string;
    constructor() {
    }
}
