export class Vendors {
    public vid: number;
    public vname : string;
    public vphno: string;
    public vusername : string;
    public vpassword : string;
    public vemail : string;
    constructor() {
    }
}
