package com.example.demo;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;


import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;


import org.springframework.dao.support.DaoSupport;

import org.springframework.web.bind.annotation.RequestMapping;
@Service
@Transactional
public class OrdersService {
	@Autowired
    private OrdersRepository repo;
	@Autowired
    private CustomerService scus;
	@Autowired
    private OrdersDAO dao;
	@Autowired 
	    private MenuDAO mdao;
	 @Autowired 
	    private WalletDAO wdao;
	 @Autowired 
	    private CustomerDAO cdao;
	    public String placeOrder(Orders order) {
	        Menu menu = mdao.searchmenu(order.getOmid());
	        customer cus=scus.get(order.getOcid());
	        Wallet wallet = wdao.showwallets(order.getOcid(), order.getWal_source());
	        double balance = wallet.getWAL_AMOUNT();
	        double billAmount = order.getOrd_quantity()*menu.getMprice();
	        int bill = (int) billAmount;
	        System.out.println(balance);
	        System.out.println(billAmount);
	        if (balance-bill > 0) {
	        	order.setOid(dao.generateId());
	            order.setOrd_status("PENDING");
	            order.setOrd_billamount(bill);
	            repo.save(order);
	            SendEmail.sendemail();  
	            final String ACCOUNT_SID = "AC0558b66c719511744aa3d382ec8da7ee"; 
		           final String AUTH_TOKEN = "eca79a9dd73e9dcf6a8328de73ea1cd8"; 
		         
		         
		              Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		              Message message = Message.creator( 
		                        new com.twilio.type.PhoneNumber("+91"+ cus.getCphno()),  
		                        "MGb89937996897d4d3320dd2193c152c8e", 
		                        " Thankyou"+cus.getCname()+" for placing an order Have a nice day \nYour order Details ! \n  Customer ID : " + Integer.toString(order.getOcid()) + "\nStatus:" + order.getOrd_status() + 
		                		"\n Bill Amount : " + Double.toString(order.getOrd_billamount()) + 
		                		"\n Order Quantity : " +Integer.toString(order.getOrd_quantity()))      
		                    .create(); 
		         
		                System.out.println(message.getSid()); 
	            wdao.updateWallet(order.getOcid(), order.getWal_source(), bill);
	            return "Order Placed Successfully...and Amount Debited";
	        }
	        return "Insufficient Funds...";
	    }
	    public String acceptOrRejectOrder(int oid,int ovid,String ord_status) {
			Orders orders = dao.searchByOrderId(oid);
			int vid = orders.getOvid();
			int cid = orders.getOcid();
			String walType = orders.getWal_source();
			double billAmount = orders.getOrd_billamount();
			if (vid!=ovid) {
				return "You are unauthorized vendor...";
			} 
			if (ord_status.toUpperCase().equals("YES")) {
				return dao.updateStatus(oid,"ACCEPTED");
			} else {
				dao.updateStatus(oid, "DENIED");
				wdao.refundWallet(cid, walType, billAmount);
				return "Order Rejected and Amount Refunded...";
			}
		}
	    public void message(int oid,String ord_status)
	    {
	    	Orders order =dao.searchByOrderId(oid);
	    	  Menu menu = mdao.searchmenu(order.getOmid());
	    	  customer cus=scus.get(order.getOcid());
	          Wallet wallet = wdao.showwallets(order.getOcid(), order.getWal_source());
	          
	          final String ACCOUNT_SID="AC0558b66c719511744aa3d382ec8da7ee";	    
	          final String AUTH_TOKEN="eca79a9dd73e9dcf6a8328de73ea1cd8";
	   
	              Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
	              Message message = Message.creator( 
	                        new com.twilio.type.PhoneNumber("+91"+ cus.getCphno()),  
	                        "MG354c90a7c4c9e8cf6edd3995047df6e7", 
	                        " Thankyou"+cus.getCname()+" for placing order! Have a nice day \nYour order Details ! \n  Customer ID : " + Integer.toString(order.getOcid()) + "\nStatus:" + order.getOrd_status() + 
	                		"\n Bill Amount : " + Double.toString(order.getOrd_billamount()) + 
	                		"\n Order Quantity : " +Integer.toString(order.getOrd_quantity()))      
	                    .create(); 
	         
	                System.out.println(message.getSid()); 
	          }

	    public List<Orders> showOrders() {
	        return repo.findAll();
	    }
		 public Orders get(int id) {
		     return repo.findById(id).get();
		    
		 }
    public List<Orders> vsorders(int ovid) {
		// TODO Auto-generated method stub
		return dao.vsorders(ovid);
	}
    public List<Orders> vporders(int ovid) {
		// TODO Auto-generated method stub
		return dao.vporders(ovid);
	}
    
    public List<Orders> sorders(int ocid) {
		// TODO Auto-generated method stub
		return dao.sorders(ocid);
	}
    public List<Orders> porders(int ocid) {
		// TODO Auto-generated method stub
		return dao.porders(ocid);
	}
    public int generateId()
    {
    	return dao.generateId();
    }
    }

 
	   
